package com.maro.dama15;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class MainActivity extends Activity {
 static { System.loadLibrary("dama_engine"); }
 private WebView web;
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 public native String nativeSolve(String input);
 public class EngineBridge {
  @JavascriptInterface public void solve(String payload){
   worker.execute(()->{
    int separator = payload == null ? -1 : payload.indexOf('|');
    String generation = separator >= 0 ? payload.substring(0,separator) : "-1";
    String request = separator >= 0 ? payload.substring(separator+1) : "";
    String result;
    try { result=nativeSolve(request); } catch(Throwable e){ result="ERROR "+e.getMessage(); }
    final String escaped=org.json.JSONObject.quote(generation + "|" + result);
    runOnUiThread(()->web.evaluateJavascript("window.damaNativeResult("+escaped+")",null));
   });
  }
 }
 @Override public void onCreate(Bundle state){super.onCreate(state);web=new WebView(this);
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.addJavascriptInterface(new EngineBridge(),"DamaNative");
  web.setWebViewClient(new WebViewClient());setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onDestroy(){worker.shutdownNow();web.destroy();super.onDestroy();}
}
