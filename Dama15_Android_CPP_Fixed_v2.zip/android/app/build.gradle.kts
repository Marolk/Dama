plugins { id("com.android.application") }
android {
 namespace = "com.maro.dama15"; compileSdk = 35
 defaultConfig { applicationId = "com.maro.dama15"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "3.0-cpp-native"
   externalNativeBuild { cmake { cppFlags += "-std=c++20 -O3" } }
 }
 externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
}
