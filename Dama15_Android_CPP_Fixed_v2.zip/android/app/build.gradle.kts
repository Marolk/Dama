plugins { id("com.android.application") }
android {
 namespace = "com.maro.dama15"; compileSdk = 35
 defaultConfig { applicationId = "com.maro.dama15"; minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "3.1-autosave"
   externalNativeBuild { cmake { cppFlags += "-std=c++20 -O3" } }
 }
 externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
}
