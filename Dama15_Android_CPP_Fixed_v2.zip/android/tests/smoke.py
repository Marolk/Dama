import subprocess,sys
engine=sys.argv[1]
for n in (8,10):
 a=[0]*(n*n)
 for r in range(3):
  for c in range(n):
   if (r+c)%2==1:a[r*n+c]=-1
 for r in range(n-3,n):
  for c in range(n):
   if (r+c)%2==1:a[r*n+c]=1
 payload=' '.join(map(str,[n,-1,100,2,*a]))
 p=subprocess.run([engine],input=payload,text=True,capture_output=True,timeout=10,check=True)
 parts=list(map(int,p.stdout.strip().split()))
 assert len(parts)>5 and 0<=parts[0]<n*n and 0<=parts[1]<n*n,(n,p.stdout,p.stderr)
 assert parts[2]>=0
 print('PASS native C++ initial',n,'x',n,'move',parts[0],parts[1])
# Fail cleanly with no legal moves
payload=' '.join(map(str,[8,-1,50,1]+[0]*64))
p=subprocess.run([engine],input=payload,text=True,capture_output=True,timeout=10,check=True)
assert p.stdout.startswith('ERROR no legal moves'),p.stdout
print('PASS C++ no-moves guard')
