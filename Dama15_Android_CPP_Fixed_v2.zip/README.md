# Dama 15 Ultimate — Android C++ native APK project

This Android project embeds the AI engine as **C++20** compiled with **Android NDK/JNI**. It does **not** use WebAssembly; this is a native C++ alternative. JavaScript renders the game board and enforces display/interactions, but **does not search for AI moves**. AI runs in a background Java ExecutorService calling native C++; no JS AI fallback.

The APK packages `android/app/src/main/assets/index.html` and native compiled `libdama_engine.so`. It works offline after installation. Source project is prepared for GitHub Actions; the workflow outputs the debug APK as a downloadable artifact.

## Build

1. Add `android/` and `.github/workflows/android-apk.yml` to repository `Marolk/Dama` preserving folders. No existing files need be deleted.
2. On GitHub Actions, select **Build Dama 15 C++ Android APK** > **Run workflow**.
3. Download the `Dama15-Ultimate-APK` artifact after a successful run, unzip, then install `app-debug.apk` on your phone.

Or open `android/` in Android Studio and run Gradle task `:app:assembleDebug` with Android SDK 35, NDK 27.2.12479018 and CMake 3.22.1 installed.

## Status and limits

The local C++ engine can be compiled and smoke-tested with g++ on Linux. An Android APK has **not** been compiled in this environment because Android SDK/NDK/Gradle are unavailable. Device/WebView compatibility and comprehensive game-rule correctness remain unverified until Android CI and device tests complete. A browser Web Worker is not used here: native computation is isolated in Java ExecutorService.

The maximum-capture move generation is based on the original project implementation. Do not claim grandmaster strength from these tests.

## Verified bridge fix (2026-11-06)
The JavaScript UI sends `generation|board-data`. `EngineBridge` now strips generation before calling native C++ and includes it again on the callback response, preventing invalid-header errors and allowing the UI to discard stale replies. This fix has not yet been tested on a real Android device.
